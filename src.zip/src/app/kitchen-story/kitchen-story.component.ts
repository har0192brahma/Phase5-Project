import { Component } from '@angular/core';

@Component({
  selector: 'app-kitchen-story',
  templateUrl: './kitchen-story.component.html',
  styleUrls: ['./kitchen-story.component.css']
})
export class KitchenStoryComponent {

}
