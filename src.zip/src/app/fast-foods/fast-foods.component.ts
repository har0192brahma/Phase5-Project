import { Component } from '@angular/core';

@Component({
  selector: 'app-fast-foods',
  templateUrl: './fast-foods.component.html',
  styleUrls: ['./fast-foods.component.css']
})
export class FastFoodsComponent {

}
